<!---->
<!-- -->
<!--  -->
<!--   -->
<?php
	include ('db__connection.php');
    include ('header.php')
?>
<body class="about__me__page__body">
    </nav>
    <div class="about__me__page__body__inner">
        <h1>about me</h1>
        <hr>
        <div class="about__me__content">
            <p>
                Dedicating myself to tasks and making sure they are well structured,
                so they can operate cohesively and concisely is something I pride 
                myself on. Along with this, turning my passion hobby of programming
                into a professional and enriching career is something I am keen to achieve.
            </p>
            <p>            
                Through opportunities in education and participating in alpha/beta testing
                of numerous app & games I have gained a decent understanding of how to 
                analyse and effective give feedback that not only helps the projects.
                But also to bolster my own ability. Teaching myself basic programming 
                from a young age, I continue to learn and increase my ability daily, 
                enjoying the process with every step.
            </p>
            <p>
                Able to break down most tasks and have a competent understanding of the 
                tools needed, allows me to maximise my productivity and workflow.  
                From this, I find myself being able to plan more efficiently and 
                communicate this clearly when working as part of a team. 
            </p>
        </div>
        <hr>
    </div>
   
        
</body>
</html>