<!---->
<!-- -->
<!--  -->
<!--   -->
<?php
    include ('header.php');
    include ('contact__submit.php');
?>
<body>

    <div class="form__success__message">
        
        <a href="index.php">
            <h1>
                details sent sucessfully
            </h1>
            <h2>click here to return to home</h2>
        </a>
    </div>

    <script src="jquery-3.6.0.js"></script>
</body>
</html>